package com.banca.aplicacion;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;


/**
 * Provee un web server que expone un sitio web mínimo en el puerto 8081 para la simulación de ataques XSS:
 * 
 * <p>
 * <b> URL: http://localhost:8081/banca </b>
 * <br>
 * Requiere mínimo: OpenJDK Runtime Environment (build 21+35-2513) 
 * </p>
 * 
 * @author csantucci
 * @since 1.0
 *
 */
public class BancoHttpServer {

	public static void main(String[] args) throws IOException {
        System.out.println("Iniciando Sitio Web del Banco");
        com.sun.net.httpserver.HttpServer server = com.sun.net.httpserver.HttpServer.create(new InetSocketAddress("localhost", 8081), 0);
        ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) Executors.newFixedThreadPool(10);        
        server.createContext("/banca", new BancoHttpServer().new MyHttpHandler());        
        server.setExecutor(threadPoolExecutor);        
        server.start();        
        System.out.println(" Servidor iniciado en el puerto 8081");
    }    
	
    /**
    *
    *<p>
    * <b> "Controlador" del Servidor Web </b>
    * <br>
    * </p>
    *
    */
	public class MyHttpHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if("GET".equals(exchange.getRequestMethod()) && exchange.getRequestURI().getQuery() != null && exchange.getRequestURI().getQuery().contains("productName")) {
                handleResponse(exchange, getSearchPage(exchange.getRequestURI().getQuery()));
            } else {
                handleResponse(exchange, getDefaultPage());
            }
        }        
        
        /**
        *
        *<p>
        * <b> Genera el HTML de la página por defecto </b>
        * <br>
        * </p>
        *
        */
        private String getDefaultPage() {
            StringBuilder htmlBuilder = new StringBuilder();
            htmlBuilder.append("<html><body><form action=\"\" method=\"get\">\n" +
                    "  <div>\n" +
                    "    <label for=\"name\">Nombre del Producto: </label>\n" +
                    "    <input size=\"100\" type=\"text\" name=\"productName\" id=\"productName\">\n" +
                    "    <input type=\"submit\" value=\"Buscar\">\n" +
                    "  </div>\n" +
                    "</form>").append("</body></html>");
            return htmlBuilder.toString();
        }        
        
        /**
        *
        *<p>
        * <b> Genera el HTML de la página de busqueda </b>
        * <br>
        * </p>
        *
        */
        private String getSearchPage(String query) {
            System.out.println("Consulta: " + query);
            query = query.substring(query.indexOf("=") + 1);
            String searchParam = query.replace("+", " ");
            StringBuilder htmlBuilder = new StringBuilder();
            htmlBuilder.append("<html><body><form action=\"search\" method=\"get\">\n" +
                    "  <div><span>").append(searchParam).append("</span></div></body></html>");
            return htmlBuilder.toString();
        }        
        
        private void handleResponse(HttpExchange exchange, String htmlResponse) throws IOException {
            OutputStream outputStream = exchange.getResponseBody();
            exchange.sendResponseHeaders(200, htmlResponse.length());
            outputStream.write(htmlResponse.getBytes());
            outputStream.flush();
            outputStream.close();
        }
    }
	
}
